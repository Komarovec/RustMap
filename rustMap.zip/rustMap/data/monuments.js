var monuments = 
[
    {
        "id":"harbor",
        "Název":"Harbor",
        "Typ":"Monument",
        "Radiace":"Žádná",
        "Kořist":"Malá, barely, bedny, vojenské truhly(1-2)",
        "Výskyt vzácných truhel":"velmi nízký",
        "Utility":"Recycler, Oil refinery",
        "Popis":"Harbor, je lokace s žádnou radiací, ale s nízkým lootem, což ho dělá ideální pro začínající hráče. Vyskytuje se ve dvou podobách (Large, Small), lze tam nalézt recycler a vysokou šanci na spawn má i oil refinery."
    },
    {
        "id":"mining_outpost",
        "Název":"Mining outpost",
        "Typ":"Malý Monument",
        "Radiace":"Žádná",
        "Kořist":"Velmi malá, barely, začátečnické truhly, bedny",
        "Výskyt vzácných truhel":"Žádný",
        "Utility":"Recycler, Repair bench",
        "Popis":"Mining outpost, od Devblogu 189 nazývaný jako Warehouse (Byla odebrána blízká quarry), je malý monument bez radiace vypadající jako skladiště, kde se často vyskytují komponenty jako (geary, springy, ...) a další základní věci spolu s recyclerem a repair benchi."
    },
    {
        "id":"quarry",
        "Název":"Quarry",
        "Typ":"Quarry",
        "Radiace":"Žádná",
        "Kořist":"Skoro žádná, jídlo, pár komponentů",
        "Výskyt vzácných truhel":"Žádný",
        "Utility":"Žádné",
        "Popis":"Quarry, je težící stanice napájená Low Grade Fuelem, vytěží enormní množství rud, aproto je to taky často okupovaná oblast hráčema, kteří jsou líní težit. Quarry může težit všechny rudy (HQM, Sulfur, Stone, Iron)."
    },
    {
        "id":"market",
        "Název":"Market",
        "Typ":"Malý Monument",
        "Radiace":"Žádná",
        "Kořist":"Jídlo",
        "Výskyt vzácných truhel":"Žádný",
        "Utility":"Žádné",
        "Popis":"Market je velmi užitečný monument a to hlavně když máte tým o spousty hladových lidí, v maketu se totiž vyskytuje jen jídlo, ale je ho mnoho, což ho činní velmi atraktivní místo pro stavbu základny. Naneštěstí se zde nevyskytují žádné truhly ani utility."
    },
    {
        "id":"gas",
        "Název":"Oxum's gas station",
        "Typ":"Malý Monument",
        "Radiace":"Žádná",
        "Kořist":"Jídlo, velmi málo komponentů",
        "Výskyt vzácných truhel":"Žádný",
        "Utility":"Žádné",
        "Popis":"Gas station je malý monument připomínající benzínku, vyskytuje se v ní převážně jídlo ale né moc."
    },
    {
        "id":"cave",
        "Název":"Cave",
        "Typ":"Jeskyně",
        "Radiace":"Žádná",
        "Kořist":"Rudy, vozíky s malým lootem, bedny",
        "Výskyt vzácných truhel":"Žádný",
        "Utility":"Žádné",
        "Popis":"Jeskyně jsou perfektní možnos pro težení jakékoliv rudy, její rozsáhly systém chodeb je dostatečně velký abyjste si odnesli plný inventář rud, ale také je možné na určených mistech v jeskyni stavět, což umožňuje děla sice malé ale velmi dobře chráněné stavby."
    },
    {
        "id":"lighthouse",
        "Název":"Lighthouse",
        "Typ":"Malý Monument",
        "Radiace":"Žádná",
        "Kořist":"Velmi malá, barely, jídlo",
        "Výskyt vzácných truhel":"Žádný",
        "Utility":"Recycler",
        "Popis":"Maják, je velmi malý monument vyskytující se na pobřeží, jeho hlavní předností je výskyt recycleru."
    },
    {
        "id":"airfield",
        "Název":"Airfield",
        "Typ":"Velký Monument",
        "Radiace":"Střední",
        "Kořist":"Velká, barely, bedny, jídlo, vojenské truhly(6-8)",
        "Výskyt vzácných truhel":"Vysoký",
        "Utility":"Recycler, refinery, repair bench, research table",
        "Popis":"Letiště je jeden z nejvyhledávanějších monumentů v Rustu, a to hlavně kvůli výskytu vojenských truhel, které se zde vyskytují ve velké míře. Letiště je taky jediný monument, přes který vždy musí přeletět helikoptéra."
    },
    {
        "id":"dome",
        "Název":"The Sphere Tank",
        "Typ":"Velký Monument",
        "Radiace":"Vysoká",
        "Kořist":"Velká, barely, vojenské truhly(4)",
        "Výskyt vzácných truhel":"Vysoký (Vzhledem k rozloze)",
        "Utility":"2x Refinery",
        "Popis":"\"Sféra\" nebo také dome, oil tank nebo Koule jsou názvy pro monument, který je postaven vedle dvou obrovksých sil. Všechna kořist se vyskytuje na vrchní části koule, kde se sice težko dostává, ale odměna je značná a hlavně je vše na jednom místě. Je tu ale velké riziko spadnutí a tedy následné smrti. Na serverech s velkou populací je Koule střed zájmu a tak se zní stává ultimátní biteví pole."
    },
    {
        "id":"satellite",
        "Název":"Satellite Dish Array",
        "Typ":"Střední Monument",
        "Radiace":"Střední",
        "Kořist":"Střední, barely, bedny, jídlo",
        "Výskyt vzácných truhel":"Žádný",
        "Utility":"Research table, recycler",
        "Popis":"Satelity jsou střední monument, který nemá moc co nabídnout jeho rozloha ho dělá obtížným na průzkum a proto je většinou opuštěný, všechen lepší loot je soustředěn do dvou malých kontejnerů v blízkosti."
    },
    {
        "id":"junkyard",
        "Název":"Junkyard",
        "Typ":"Střední Monument",
        "Radiace":"Střední",
        "Kořist":"Střední, barely, bedny",
        "Výskyt vzácných truhel":"Žádný",
        "Utility":"Žadné",
        "Popis":"Junkyard je střední monument, který je obehnán dráťeným plotem, vyskytují se zde barely, a dřevěné bedny."
    },
    {
        "id":"train_yard",
        "Název":"Industrial Train Yard",
        "Typ":"Velký Monument",
        "Radiace":"Velká",
        "Kořist":"Velká, barely, bedny, jídlo, vojenské truhly(4-6)",
        "Výskyt vzácných truhel":"Střední",
        "Utility":"Research table, recycler, oil refinery, repair bench",
        "Popis":"Train Yard, je rozlohově velký monument plný betonových budov, vyskytují se zde vojenské truhly, ale tento monument je atraktivní hlavně díky Pump Jacku, který se málo vyskytuje, a proto býva často navštěvován."
    },
    {
        "id":"sewer_branch",
        "Název":"Sewer Branch",
        "Typ":"Střední Monument",
        "Radiace":"Střední",
        "Kořist":"Střední, barely, bedny, jídlo, vojenské truhly(2-4)",
        "Výskyt vzácných truhel":"Střední",
        "Utility":"Recycler",
        "Popis":"Sewer Branch je monument, který na povrchu vypadá velmi nenápadně, ale podzemí se vyskytuje síť stok, kde se dají nalézt bedny a vojenské truhly. Díky své rozlehlosti a nutnosti světelného zdroje při průzkumu je většinou opuštěný."
    },
    {
        "id":"water_treatment",
        "Název":"Water Treatment Plant",
        "Typ":"Velký Monument",
        "Radiace":"Velká",
        "Kořist":"Střední, barely, bedny, jídlo, vojenské truhly(2-4)",
        "Výskyt vzácných truhel":"Střední",
        "Utility":"Recycler, repair bench",
        "Popis":"Water Treatment Plant je velký monument, který připomíná čistírnu odpadních vod, nachází se v repair bench a recycler, v blízkosti se také může objevit Pump Jack, Všechen lepší loot je soustředěn na Vodní nádrže na které se špatně dostává, málo navštěvovaný."
    },
    {
        "id":"launch_site",
        "Název":"Launch Site",
        "Typ":"Největší Monument",
        "Radiace":"Enormní (Hlavně v hlavní budově, ani Hazmat suit není dost)",
        "Kořist":"Obrovská, barely, bedny, jídlo, Elite cratky(2-4), APC",
        "Výskyt vzácných truhel":"Velmi vysoký",
        "Utility":"Recycler, repair bench, research table, refinery",
        "Popis":"Raketové odpaliště, je největší monument ve hře, disponuje řadou obrovských betonových budov plné lootu, kromě hlavní budovy v centru, na které se běžně vyskytují Elite cratky, se zde projíždí APC Bradley, který je výzvou pro každého kdo tento monument navštíví."
    },
    {
        "id":"military_tunnel",
        "Název":"Military Tunnel",
        "Typ":"Velký Monument",
        "Radiace":"Velmi vysoká",
        "Kořist":"Obrovská, barely, bedny, jídlo, Elite cratky(2) + Vojenské truhly",
        "Výskyt vzácných truhel":"Velmi vysoký",
        "Utility":"Recycler, repair bench, research table, refinery",
        "Popis":"Military tunnel je v poslední době velmi oživený monument a to ne jenom kvůli svému lootu, ale hlavně díky Scientistům, nebo-li počítačem ovládaní nepřátelé v Anti-radiačních oblecích, kteří chrání vojenské tunely před všemi, kteří by se opovážili tunely navštívit."
    },
    {
        "id":"power_plant",
        "Název":"Power Plant",
        "Typ":"Velký Monument",
        "Radiace":"Vysoká",
        "Kořist":"Velká, barely, bedny, jídlo, Vojenské truhly(4-6)",
        "Výskyt vzácných truhel":"Vysoký",
        "Utility":"Recycler, repair bench, research table, refinery",
        "Popis":"Power plant je velký monument pyšnící se chladícími věžmi, jaderným reaktorem a skvělým lootem, často navštěvovany."
    }
]