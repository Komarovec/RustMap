
function findJSONObject(data, attr, value) {
    var obj;
    data.forEach(function(element) {
      if (element[attr] === value) {
        obj = element;
      }
    });
    return obj;
}

function listOfDetails(obj) {
    var result = "<ul>";
    for (var key in obj) {
      if (obj.hasOwnProperty(key)) {
        if(key == "id") continue; 
        result += "<li>" + key + ": <b>" + obj[key] + "</b></li>";
      }
    }
    result += "</ul>";
    return result;
  }

$(function() {
    $("ellipse").on("click", function() {
        console.log($(this).attr("id"));
        var obj = findJSONObject(monuments,"id", $(this).attr("id"));
        if(obj === undefined) return;
        details(obj);
    })
    $("circle").on("click", function() {
        console.log($(this).attr("id"));
        var obj = findJSONObject(monuments,"id", $(this).attr("id"));
        if(obj === undefined) return;
        details(obj);
    })
});

function details(obj) {
    document.getElementById("info").innerHTML = "<h3>"+obj.Název+"</h3>";
    document.getElementById("info").innerHTML += listOfDetails(obj);
}